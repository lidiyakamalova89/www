PROGRAM WILL NOT START?
1. Disable antivirus and Windows Defender
2. Download and install Microsoft Visual C++
3. Launch the program
4. The computer reboots automatically

PASS - osth